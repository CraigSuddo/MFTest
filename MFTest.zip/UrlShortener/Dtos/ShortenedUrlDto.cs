namespace UrlShortener.Dtos
{
    public sealed class ShortenedUrlDto
    {
        public string ShortenedUrl { get; set;}
    }
}