namespace UrlShortener.Dtos
{
    public sealed class UrlDto
    {
        public string Url { get; set; }
    }
}